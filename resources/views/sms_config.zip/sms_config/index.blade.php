@extends('layouts.app')

@section('content')
<div class="container">
    <h3 class="mb-4"><i class="fa-solid fa-mobile-screen-button me-2"></i> SMS Configuration</h3>

    <form action="{{ route('sms-config.update') }}" method="POST">
        @csrf
        @method('PUT')

        <div class="row">

            <!-- SMS API URL -->
            <div class="col-md-6 mb-3">
                <label class="form-label">SMS API URL *</label>
                <input type="text" name="api_url" class="form-control"
                       value="{{ old('api_url', $config->api_url ?? '') }}" required>
                @error('api_url')
                    <small class="text-danger">{{ $message }}</small>
                @enderror
            </div>

            <!-- API Key -->
            <div class="col-md-6 mb-3">
                <label class="form-label">API Key / Token *</label>
                <input type="text" name="api_key" class="form-control"
                       value="{{ old('api_key', $config->api_key ?? '') }}" required>
                @error('api_key')
                    <small class="text-danger">{{ $message }}</small>
                @enderror
            </div>

            <!-- Sender ID -->
            <div class="col-md-6 mb-3">
                <label class="form-label">Sender ID (optional)</label>
                <input type="text" name="sender_id" class="form-control"
                       value="{{ old('sender_id', $config->sender_id ?? '') }}">
            </div>
        </div>

        <!-- Buttons -->
        <div class="d-flex justify-content-end gap-2">
            <button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#testSmsModal">
                <i class="fa-solid fa-paper-plane"></i> Test SMS
            </button>
            <button class="btn btn-success">
                <i class="fa-solid fa-save"></i> Save Settings
            </button>
        </div>
    </form>
</div>

<!-- Test SMS Modal -->
<div class="modal fade" id="testSmsModal" tabindex="-1">
  <div class="modal-dialog">
    <form id="testSmsForm" method="POST">
        @csrf
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Send Test SMS</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
              <label>Enter Phone Number</label>
              <input type="text" id="testPhone" class="form-control" placeholder="e.g. +11234567890" required>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="button" class="btn btn-primary" onclick="sendTestSms()">Send Test SMS</button>
          </div>
        </div>
    </form>
  </div>
</div>
@endsection

@push('scripts')
<script>
function sendTestSms() {
    const phone = document.getElementById('testPhone').value;
    fetch("{{ route('sms-config.test') }}", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "X-CSRF-TOKEN": "{{ csrf_token() }}"
        },
        body: JSON.stringify({ phone: phone })
    })
    .then(res => res.json())
    .then(data => alert(data.message))
    .catch(err => alert('Test SMS failed.'));
}
</script>
@endpush
